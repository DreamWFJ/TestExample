# -*- coding: utf-8 -*-
# ===================================
# ScriptName : ctrl_terminal.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-12-02 15:16
# ===================================
import tornado.web
from .base import BaseHandler

class ToCtrlTerminalHTML(BaseHandler):
    def get(self, *args, **kwargs):
        self.render("node/node_terminal.html")

class CtrlTerminalHandler(BaseHandler):
    def get(self, *args, **kwargs):
        pass

    def post(self, *args, **kwargs):
        pass



class LoadHTMLStringModule(tornado.web.UIModule):
    def render(self, html_string):
        # html = tornado.template.Template(html_string)
        return html_string


class TerminalModule(tornado.web.UIModule):
    def render(self, author=''):
        return self.render_string("node/node_terminal.html", author=author)

    def css_files(self):
        return ["/static/css/jquery_terminal/jquery.terminal.min.css",
                "/static/module/css/node-terminal.css"]

    def javascript_files(self):
        return ["/static/js/jquery_terminal/jquery.terminal.min.js",
                "/static/js/jquery_terminal/jquery.mousewheel-min.js",
                "/static/module/js/node-terminal.js"]