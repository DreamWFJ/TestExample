# -*- coding: utf-8 -*-
# ===================================
# ScriptName : task.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-12-01 14:51
# ===================================
import json
import pprint
from .base import BaseHandler

class ToNodeTaskHTML(BaseHandler):
    def get(self, *args, **kwargs):
        self.render("node/node_task.html")

class NodeBingTaskHandler(BaseHandler):
    def get(self, *args, **kwargs):
        total_sql = """SELECT COUNT(*) FROM node_time_task """
        task_sql = "select _id, node_id, task_id, is_period_execute, first_execute_time, time_task_period_num, " \
                   "time_task_period_unit from node_time_task "
        # 查询域
        search_departmentname = self.get_argument('departmentname', None)
        search_statu = self.get_argument('statu', None)
        print search_departmentname, search_statu, type(search_statu)

        order_type = self.get_argument("order", "asc")
        sort_name = self.get_argument('sort', "_id")
        task_sql += " ORDER BY %s %s "%(sort_name, order_type)

        offset = self.get_argument('offset', None)
        limit = self.get_argument('limit', None)
        task_sql += " LIMIT {limit} OFFSET {offset}".format(limit=limit, offset=offset) if offset is not None and limit is not None else ""


        last_data = []
        data_field = ['_id', 'node_id', 'task_id', 'is_period_execute','first_execute_time', 'time_task_period_num', 'time_task_period_unit']


        for one in self.db.find(task_sql):
            last_data.append(dict(zip(data_field, one)))
        total = self.db.find(total_sql)
        return_data = {
            "rows": last_data,
            "total": total[0][0] if total and len(total) else 0
        }

        self.write(json.dumps(return_data))


    def post(self, *args, **kwargs):
        pass

    def delete(self, *args, **kwargs):
        pass

class ToManageTaskHTML(BaseHandler):
    def get(self, *args, **kwargs):
        self.render("node/task_manage.html")

class ManageTaskHandler(BaseHandler):
    def get(self, *args, **kwargs):
        total_sql = "SELECT COUNT(*) FROM time_task "
        task_sql = "select _id, task_name, task_function_description, interpreter, download_script_file, has_binding_node, create_time from time_task "
        # 查询域
        search_departmentname = self.get_argument('departmentname', None)
        search_statu = self.get_argument('statu', None)
        print search_departmentname, search_statu, type(search_statu)

        order_type = self.get_argument("order", "asc")
        sort_name = self.get_argument('sort', "_id")
        task_sql += " ORDER BY %s %s "%(sort_name, order_type)

        offset = self.get_argument('offset', None)
        limit = self.get_argument('limit', None)
        task_sql += " LIMIT {limit} OFFSET {offset}".format(limit=limit, offset=offset) if offset is not None and limit is not None else ""


        last_data = []
        data_field = ['_id', 'task_name', 'task_function_description', 'interpreter', 'download_script_file', 'has_binding_node', 'create_time']

        print "task_sql : ", task_sql

        for one in self.db.find(task_sql):
            last_data.append(dict(zip(data_field, one)))
        total = self.db.find(total_sql)

        # pprint.pprint(last_data)
        return_data = {
            "rows": last_data,
            "total": total[0][0] if total and len(total) else 0
        }

        self.write(json.dumps(return_data))


    def post(self, *args, **kwargs):
        pass

    def delete(self, *args, **kwargs):
        pass

    