# -*- coding: utf-8 -*-
# ===================================
# ScriptName : task_schedule.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-12-08 11:16
# ===================================

import os
import time
from .node_ssh import NodeSSH
from src.db_sqlite3 import Sqlite3DB
def time2string(t):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t))


class NodeTimeTask(object):
    def __init__(self, schedule, logger):
        self.db = Sqlite3DB(os.environ["PROJECT_DATABASE_PATH"])
        self.logger = logger
        self.schedule = schedule

    def start(self):
        self.add_task()
        self.schedule.start()

    def stop(self):
        self.schedule.shutdown()

    def restart(self):
        self.stop()
        self.start()


    def add_task(self):
        query_time_task_sql = "select task_id, first_execute_time, time_task_period_num, time_task_period_unit, node_id from " \
                              "node_time_task where is_period_execute = 1"
        query_task_sql = "select download_script_file from time_task where _id=?"
        time_task_lists = self.db.find(query_time_task_sql)
        self.logger.info("need schedule task list: %s"%time_task_lists)
        for time_task in time_task_lists:
            task_id = time_task[0]
            first_execute_time = time_task[1]
            first_execute_time = first_execute_time if first_execute_time > time.time() else time.time() + 300
            time_task_period_num = time_task[2]
            time_task_period_unit = time_task[3]
            node_id = time_task[4]
            self.logger.debug("task_id: %s, first_execute_time:%s, time_task_period_num: %s, time_task_period_unit :%s"%(task_id,
                                                                first_execute_time, time_task_period_num, time_task_period_unit))
            script_file_name = self.db.find_one(query_task_sql, task_id)[0][0]

            seconds = 0
            minutes = 0
            hours = 0
            days = 0
            months = 0
            years = 0
            if time_task_period_unit.lower() == "hour":
                hours = int(time_task_period_num)
            elif time_task_period_unit.lower() == "minute":
                minutes = int(time_task_period_num)
            elif time_task_period_unit.lower() == "second":
                seconds = int(time_task_period_num)
            elif time_task_period_unit.lower() == "day":
                days = int(time_task_period_num)

            self.logger.debug("start schedule job, script name: %s, first_excute_time: %s, period: %s%s"%(script_file_name,
                                                    time2string(first_execute_time), time_task_period_num, time_task_period_unit) )
            self.schedule.add_job(self.execute_script, 'interval', name=script_file_name, seconds=seconds,
                                  minutes=minutes, hours=hours, days=days, next_run_time=time2string(first_execute_time), args=[script_file_name, node_id])


    def execute_script(self, script_name, node_id):
        script_path = os.path.join(os.environ["DOWNLOAD_SCRIPT_PATH"], script_name)
        self.logger.info("in node: %s, start execute script: %s "%(node_id, script_path))
        db = Sqlite3DB(os.environ["PROJECT_DATABASE_PATH"])
        find_sql = "select node_ip, auth_user, auth_passwd, node_port from node_manage where _id=?"
        node_info = db.find_one(find_sql, node_id)[0]
        node_ssh = NodeSSH(*node_info)
        error = node_ssh.init_ssh()
        if error:
            status = False
            message = error
            self.logger.error("init connnect error: %s -- %s"%(error, node_info))
            node_ssh.close_conn()
        else:
            result = node_ssh.execute_script(script_path)
            node_ssh.close_conn()
            self.logger.debug("script execute result = %s"%result)
            log_name = "%s.log"%time.strftime('%Y%m%d%H%M%S',time.localtime(time.time()))
            log_path = os.path.join(os.environ["DOWNLOAD_LOG_PATH"], log_name)
            # 保存脚本执行日志
            with open(log_path,'wb') as up:
                up.write(result)
            self.logger.debug("node id: '%s', update log filename: '%s' to db"%(node_id, log_name))
            # 更新日志文件到数据
            update_sql = "update manage_node set last_detect_time=%f, last_detect_log=%s where _id=?"%(time.time(), log_name)
            data = [(node_id,)]
            db.update(update_sql, data)
        del db




