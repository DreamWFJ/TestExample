#!/usr/bin/env bash
ls
pwd
# this is a test
netstat