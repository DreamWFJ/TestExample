dddd
cd /hoem
atest

adsf