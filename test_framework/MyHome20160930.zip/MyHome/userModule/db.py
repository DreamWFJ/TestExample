# -*- coding: utf-8 -*-
# ===================================
# ScriptName : db.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-28 14:46
# ===================================

def get_id_by_name(collection, query_condition):
    return collection.find_one(query_condition)
    