# -*- coding: utf-8 -*-
# ===================================
# ScriptName : exceptions.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-28 14:59
# ===================================


class NotAdminRight(Exception):
    pass

class InvalidRequest(Exception):
    pass

class Unauthentication(Exception):
    pass

class NotFoundData(Exception):
    pass