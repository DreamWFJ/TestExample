# -*- coding: utf-8 -*-
# ===================================
# ScriptName : user.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-28 10:51
# ===================================
import tornado.web
import uuid
import json
from utils.tools import cipher_hander, generate_clock_time, format_data_time
from exceptions import NotAdminRight, InvalidRequest, Unauthentication, NotFoundData

class BaseHandler(tornado.web.RequestHandler):
    def initialize(self, db):
        self.db = db

    def get_current_user(self):
        return self.get_secure_cookie("username")

class LoginHandler(BaseHandler):
    def get(self):
        self.render('user/login.html')

    def post(self):
        try:
            username = self.get_argument("username")
            password = self.get_argument("password")
            next_url = self.get_argument("next", '/')
            collection = self.db["user"]
            result = collection.find_one({"username": username, "password": cipher_hander.encrypt(password)})
            if not result:
                raise Unauthentication
            print "Your username: %s, password: %s is authenticated successfully." % (username, password)
            self.set_secure_cookie("username", self.get_argument("username"))
            print self.current_user
            # print self.get_secure_cookie("username")
            print "redirect url: ", next_url
            self.redirect(next_url)


        except Unauthentication:
            data = {
                "message": "username or password error"
            }
            self.set_status(400)
            self.write(json.dumps(data))
        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))


class IndexHandler(tornado.web.RequestHandler):
    def get_current_user(self):
        return self.get_secure_cookie("username")

    @tornado.web.authenticated
    def get(self, *args, **kwargs):
        self.render('index.html', user=self.current_user)

class LogoutHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.current_user
        self.set_secure_cookie("usernaem", user, expires_days=0)
        self.clear_cookie("username")
        # self.current_user = None
        # self.clear()
        self.redirect("/")

class NewUserHandler(tornado.web.RequestHandler):
    def initialize(self, db):
        self.db = db

    def get(self):
        role_collection = self.db['role']
        result = role_collection.find_one({"role_name": "user"})
        self.render('user/edit_user.html', role=result)

class EditUserHandler(NewUserHandler):
    def get(self, user_id=None):
        try:
            if not user_id:
                raise InvalidRequest

            user_collection = self.db['user']
            user_result = user_collection.find_one({"_id": user_id})
            if not user_result:
                raise NotFoundData
            role_collection = self.db['role']
            role_result = role_collection.find_one({"role_name": "user"})

            self.render("user/edit_user.html", user=user_result, role=role_result, user_id=user_id)

        except InvalidRequest:
            data = {
                "message": "invalid request, user id must be filled."
            }
            self.set_status(400)
            self.write(json.dumps(data))

        except NotFoundData:
            data = {
                "message": "not found data."
            }
            self.set_status(416)
            self.write(json.dumps(data))

        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))

class ForgetPasswordHandler(BaseHandler):
    def get(self, *args, **kwargs):
        pass

    def post(self, *args, **kwargs):
        pass

class UserHandler(BaseHandler):

    def _check_admin_right(self):
        try:
            user_collection = self.db['user']
            user_result = user_collection.find_one({"username": self.current_user})
            user_id = user_result["_id"]
            role_collection = self.db['role']
            role_result = role_collection.find_one({"role_name": "admin"})
            if not role_result:
                raise
            role_id = role_result["_id"]
            user_role_collection = self.db['user_role_relationship']
            user_role_collection_result = user_role_collection.find_one({"user_id":user_id, "role_id": role_id})
            if not user_role_collection_result:
                raise
        except Exception, e:
            print e.__class__.__name__, ' : ', str(e)
            raise NotAdminRight


    @tornado.web.authenticated
    def get(self, user_id=None):
        # 查询用户信息 ------------- 注意，这里后期需要添加 分页机制 ----
        try:
            query_condition = {"_id": user_id}
            if not user_id:
                query_condition = None
                self._check_admin_right()
            user_collection = self.db['user']
            result = user_collection.find(query_condition)
            if not result:
                raise NotFoundData

            result = list(result)

            # format_data_time(result)
            self.render("user/user.html", users=result, user_id=user_id)

        except NotAdminRight:
            data = {
                "message": "not handle right."
            }
            self.set_status(400)
            self.write(json.dumps(data))

        except NotFoundData:
            data = {
                "message": "not found data."
            }
            self.set_status(416)
            self.write(json.dumps(data))

        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))


    def post(self, *args, **kwargs):
        # 创建用户
        data = dict()
        try:
            username = self.get_argument("username")
            password = self.get_argument("password")
            email = self.get_argument("email")
            role_id = self.get_argument("role_id")
            user_collection = self.db["user"]
            user_id = str(uuid.uuid4())
            result = user_collection.insert_one({
                "username":     username,
                "password":     cipher_hander.encrypt(password),
                "email":        email,
                "_id":          user_id,
                "create_time":  generate_clock_time(),
                "modify_time":  None
            })
            if not result:
                raise

            user_role_relationship_collection = self.db["user_role_relationship"]
            user_role_relationship_result = user_role_relationship_collection.insert_one({
                "role_id": role_id,
                "user_id": user_id
            })
            if not user_role_relationship_result:
                raise
            self.redirect("/user")
            # data = {"message": "create user: '%s' success"%username}
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
            self.write(json.dumps(data))


    @tornado.web.authenticated
    def delete(self, user_id=None):
        # 删除用户
        data = dict()
        try:
            if not user_id:
                raise InvalidRequest
            user_collection = self.db["user"]
            user_id = str(uuid.uuid4())
            result = user_collection.delete_one({"user_id": user_id})
            if not result:
                raise
            role_collection = self.db["role"]
            result = role_collection.delete_one({"user_id": user_id})
            if not result:
                raise
            data = {"message": "delete success"}
        except InvalidRequest:
            data = {
                "message": "invalid request, user id must be filled."
            }
            self.set_status(400)
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
        finally:
            self.write(json.dumps(data))

    @tornado.web.authenticated
    def put(self, user_id=None):
        # 更新用户信息
        data = dict()
        try:
            if not user_id:
                raise InvalidRequest

            update_content = dict()
            # usename = self.get_argument("username", None)
            # if usename:
            #     update_content["username"] = usename

            age = self.get_argument("age", None)
            if age:
                update_content["age"] = age

            sex = self.get_argument("sex", None)
            if sex:
                update_content["sex"] = sex


            email = self.get_argument("email", None)
            if email:
                update_content["email"] = email

            phone_number = self.get_argument("phone_number", None)
            if phone_number:
                update_content["phone_number"] = phone_number

            qq_number = self.get_argument("qq_number", None)
            if qq_number:
                update_content["qq_number"] = qq_number

            weixin_number = self.get_argument("weixin_number", None)
            if weixin_number:
                update_content["weixin_number"] = weixin_number

            update_content["modify_time"] = generate_clock_time()
            user_collection = self.db["user"]
            print "update_content : ",update_content
            result = user_collection.update_one({"_id": user_id}, {"$set": update_content})
            if not result:
                raise

            self.redirect("/user/%s"%user_id)
        except InvalidRequest:
            data = {
                "message": "invalid request, user id must be filled."
            }
            self.set_status(400)
            self.write(json.dumps(data))

        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
            self.write(json.dumps(data))

    def _update_one_user(self, collection, filter_condition, update_content):
        return collection.update_one(filter_condition, update_content)

    @tornado.web.authenticated
    def patch(self, user_id=None):
        # 修改某个字段信息,后期可以改为if elif elif ... else的结构，把密码修改放在最前面
        self.put(user_id)