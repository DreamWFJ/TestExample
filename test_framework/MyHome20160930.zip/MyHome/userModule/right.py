# -*- coding: utf-8 -*-
# ===================================
# ScriptName : right.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-29 10:48
# ===================================

import json
import uuid
import tornado.web
from utils.tools import generate_clock_time, format_data_time
from exceptions import NotAdminRight, InvalidRequest, Unauthentication, NotFoundData


class NewRightHandler(tornado.web.RequestHandler):
    def initialize(self, db):
        self.db = db

    def get(self):
        self.render('user/edit_right.html')

class EditRightHandler(NewRightHandler):
    def get(self, right_id=None):
        try:
            if not right_id:
                raise InvalidRequest

            right_collection = self.db['right']
            result = right_collection.find_one({"_id": right_id})
            if not result:
                raise NotFoundData

            format_data_time(result)
            self.render("user/edit_right.html", right=result, right_id=right_id)

        except InvalidRequest:
            data = {
                "message": "invalid request, right id must be filled."
            }
            self.set_status(400)
            self.write(json.dumps(data))

        except NotFoundData:
            data = {
                "message": "not found data."
            }
            self.set_status(416)
            self.write(json.dumps(data))

        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))

class RightHandler(tornado.web.RequestHandler):
    def initialize(self, db):
        self.db = db

    def get_current_user(self):
        return self.get_secure_cookie("username")

    @tornado.web.authenticated
    def get(self, right_id=None):
        data = dict()
        try:
            query_condition = {"_id": right_id}
            if not right_id:
                query_condition = None
            right_collection = self.db['right']
            result = right_collection.find(query_condition)
            if not result:
                raise NotFoundData
            result = list(result)

            format_data_time(result)

            self.render("user/right.html", rights=result, right_id=right_id)

        except NotFoundData:
            data = {
                "message": "not found data."
            }
            self.set_status(416)
            self.write(json.dumps(data))

        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))

    @tornado.web.authenticated
    def post(self, *args, **kwargs):
        try:
            insert_data = []
            module_name = self.get_argument("module_name")
            module_name_alias = self.get_argument("module_name_alias", "")
            right_read_code = self.get_argument("right_read_code", None)
            if right_read_code:
                right_id = str(uuid.uuid4())
                insert_data.append({
                    "_id":                  right_id,
                    "right_code":           right_read_code,
                    "right_code_alias":     u"读",
                    "module_name":          module_name,
                    "module_name_alias":    module_name_alias,
                    "create_time":          generate_clock_time(),
                    "modify_time":          None
                })
            right_write_code = self.get_argument("right_write_code", None)
            if right_write_code:
                right_id = str(uuid.uuid4())
                insert_data.append({
                    "_id":                  right_id,
                    "right_code":           right_write_code,
                    "right_code_alias":     u"写",
                    "module_name":          module_name,
                    "module_name_alias":    module_name_alias,
                    "create_time":          generate_clock_time(),
                    "modify_time":          None
                })

            right_id = str(uuid.uuid4())
            right_collection = self.db["right"]

            result = right_collection.insert_many(insert_data)
            if not result:
                raise
            self.redirect("/right")
            # data = {"message": "insert success"}
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
            self.write(json.dumps(data))

    @tornado.web.authenticated
    def put(self, right_id=None):
        data = dict()
        try:
            if not right_id:
                raise InvalidRequest
            update_content = dict()

            right_code = self.get_argument("right_code", None)
            if right_code:
                update_content["right_code"] = right_code

            right_code_alias = self.get_argument("right_code_alias", None)
            if right_code_alias:
                update_content["right_code_alias"] = right_code_alias

            module_name = self.get_argument("module_name", None)
            if module_name:
                update_content["module_name"] = module_name

            module_name_alias = self.get_argument("module_name_alias", None)
            if module_name_alias:
                update_content["module_name_alias"] = module_name_alias

            update_content["modify_time"] = generate_clock_time()

            right_collection = self.db["right"]
            result = right_collection.update_one({"_id": right_id}, {"$set": update_content})
            if not result:
                raise
            data = {"message": "update success"}
        except InvalidRequest:
            data = {
                "message": "invalid request, right id must be filled."
            }
            self.set_status(400)
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
        finally:
            self.write(json.dumps(data))


    @tornado.web.authenticated
    def delete(self, right_id=None):
        # 这里需要判断当前角色是否已经被引用
        data = dict()
        try:
            if not right_id:
                raise InvalidRequest
            right_collection = self.db["right"]
            result = right_collection.delete_one({"_id": right_id})
            if not result:
                raise
            data = {"message": "delete success"}

        except InvalidRequest:
            data = {
                "message": "invalid request, right id must be filled."
            }
            self.set_status(400)
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
        finally:
            self.write(json.dumps(data))

