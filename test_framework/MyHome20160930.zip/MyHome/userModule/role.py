# -*- coding: utf-8 -*-
# ===================================
# ScriptName : role.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-29 10:39
# ===================================
import json
import uuid
import tornado.web
from utils.tools import generate_clock_time, format_data_time
from exceptions import InvalidRequest, NotFoundData

class NewRoleHandler(tornado.web.RequestHandler):
    def initialize(self, db):
        self.db = db

    def get(self):
        self.render('user/edit_role.html')

class EditRoleHandler(NewRoleHandler):
    def get(self, role_id=None):
        try:
            if not role_id:
                raise InvalidRequest

            role_collection = self.db['role']
            result = role_collection.find_one({"_id": role_id})
            if not result:
                raise NotFoundData

            format_data_time(result)
            self.render("user/edit_role.html", role=result, role_id=role_id)

        except InvalidRequest:
            data = {
                "message": "invalid request, role id must be filled."
            }
            self.set_status(400)
            self.write(json.dumps(data))

        except NotFoundData:
            data = {
                "message": "not found data."
            }
            self.set_status(416)
            self.write(json.dumps(data))

        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))

class RoleHandler(tornado.web.RequestHandler):
    def initialize(self, db):
        self.db = db

    def get_current_user(self):
        return self.get_secure_cookie("username")

    @tornado.web.authenticated
    def get(self, role_id=None):
        data = dict()
        try:
            query_condition = {"_id": role_id}
            if not role_id:
                query_condition = None
            role_collection = self.db['role']
            result = role_collection.find(query_condition)
            if not result:
                raise NotFoundData
            result = list(result)

            format_data_time(result)
            self.render("user/role.html", roles=result, role_id=role_id)

        except NotFoundData:
            data = {
                "message": "not found data."
            }
            self.set_status(416)
            self.write(json.dumps(data))

        except Exception, e:
            import traceback
            traceback.print_exc()
            data = {
                "message": "server internal error '[%s]: %s'"%(e.__class__.__name__, str(e))
            }
            self.set_status(500)
            self.write(json.dumps(data))

    @tornado.web.authenticated
    def post(self, *args, **kwargs):
        try:
            role_name = self.get_argument("role_name")
            role_name_alias = self.get_argument("role_name_alias", "")
            role_id = str(uuid.uuid4())
            role_collection = self.db["role"]

            result = role_collection.insert_one({
                "_id":              role_id,
                "role_name":        role_name,
                "role_name_alias":  role_name_alias,
                "create_time":      generate_clock_time(),
                "modify_time":      None
            })
            if not result:
                raise

            self.redirect("/role")
            # data = {"message": "insert success"}
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
            self.write(json.dumps(data))

    @tornado.web.authenticated
    def put(self, role_id=None):
        data = dict()
        try:
            if not role_id:
                raise InvalidRequest
            update_content = dict()
            role_name = self.get_argument("role_name", None)
            if role_name:
                update_content["role_name"] = role_name

            role_name_alias = self.get_argument("role_name_alias", None)
            if role_name_alias:
                update_content["role_name_alias"] = role_name_alias

            update_content["modify_time"] = generate_clock_time()

            role_collection = self.db["role"]
            result = role_collection.update_one({"_id": role_id}, {"$set": update_content})
            if not result:
                raise
            data = {"message": "update success"}
        except InvalidRequest:
            data = {
                "message": "invalid request, role id must be filled."
            }
            self.set_status(400)
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
        finally:
            self.write(json.dumps(data))


    @tornado.web.authenticated
    def delete(self, role_id=None):
        # 这里需要判断当前角色是否已经被引用
        data = dict()
        try:
            if not role_id:
                raise InvalidRequest
            role_collection = self.db["role"]
            result = role_collection.delete_one({"_id": role_id})
            if not result:
                raise
            data = {"message": "delete success"}

        except InvalidRequest:
            data = {
                "message": "invalid request, role id must be filled."
            }
            self.set_status(400)
        except Exception, e:

            data = {
                "message": "server internal error '%s'"%str(e)
            }
            self.set_status(500)
        finally:
            self.write(json.dumps(data))


