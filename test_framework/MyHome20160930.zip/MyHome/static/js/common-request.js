/**
 * Created by WFJ on 2016/9/28.
 */
/**
 * Created by Administrator on 2016/9/16.
 */
function request_server(request_url, request_type, request_data){
    alert(request_url);
    jQuery.ajax({
        url: request_url,
        type: request_type,
        data: request_data,
        dataType: 'json',
        beforeSend: function(xhr, settings) {
            $(event.target).attr('disabled', 'disabled');
        },
        success: function(data, status, xhr) {
            alert(data.message)
        }
    });
}

function jump_to_the_specified_addr(url)
{
    window.location.href = url;
}

//$(document).ready(function() {
//    document.session = $('#session').val();
//
//    setTimeout(requestInventory, 100);
//
//    $('#add-button').click(function(event) {
//        jQuery.ajax({
//            url: '//localhost:8000/cart',
//            type: 'POST',
//            data: {
//                session: document.session,
//                action: 'add'
//            },
//            dataType: 'json',
//            beforeSend: function(xhr, settings) {
//                $(event.target).attr('disabled', 'disabled');
//            },
//            success: function(data, status, xhr) {
//                $('#add-to-cart').hide();
//                $('#remove-from-cart').show();
//                $(event.target).removeAttr('disabled');
//            }
//        });
//    });
//
//    $('#remove-button').click(function(event) {
//        jQuery.ajax({
//            url: '//localhost:8000/cart',
//            type: 'POST',
//            data: {
//                session: document.session,
//                action: 'remove'
//            },
//            dataType: 'json',
//            beforeSend: function(xhr, settings) {
//                $(event.target).attr('disabled', 'disabled');
//            },
//            success: function(data, status, xhr) {
//                $('#remove-from-cart').hide();
//                $('#add-to-cart').show();
//                $(event.target).removeAttr('disabled');
//            }
//        });
//    });
//});
//
//function requestInventory() {
//    jQuery.getJSON('//localhost:8000/cart/status', {session: document.session},
//        function(data, status, xhr) {
//            $('#count').html(data['inventoryCount']);
//            setTimeout(requestInventory, 0);
//        }
//    );
//}
//
////貌似需要最新新的浏览器支持
//function requestInventory1() {
//    var host = 'ws://localhost:8000/cart/status';
//
//    var websocket = new WebSocket(host);
//
//    websocket.onopen = function (evt) { };
//    websocket.onmessage = function(evt) {
//        $('#count').html($.parseJSON(evt.data)['inventoryCount']);
//    };
//    websocket.onerror = function (evt) { };
//}