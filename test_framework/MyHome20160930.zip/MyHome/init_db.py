# -*- coding: utf-8 -*-
# ===================================
# ScriptName : init_db.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-29 15:24
# ===================================

import pymongo
import time
import uuid
from utils.tools import cipher_hander, generate_clock_time

def generate_id():
    return str(uuid.uuid4())


def __clear_collection(conn):
    db = conn["UserManage"]
    db.drop_collection("role")
    db.drop_collection("user")
    db.drop_collection("right")
    db.drop_collection("user_role_relationship")
    db.drop_collection("role_right_relationship")

def __init_role(conn):
    db = conn["UserManage"]
    collection = db["role"]
    admin_id = generate_id()
    user_id = generate_id()
    guest_id = generate_id()
    collection.insert_many([
        {"role_name": "admin", "role_name_alias": u"管理员", "_id": admin_id, "create_time": generate_clock_time(), "modify_time": None},
        {"role_name": "user",  "role_name_alias": u"普通",   "_id": user_id,  "create_time": generate_clock_time(), "modify_time": None},
        {"role_name": "guest", "role_name_alias": u"匿名",   "_id": guest_id, "create_time": generate_clock_time(), "modify_time": None},

    ])
    return admin_id, user_id, guest_id

def __init_user(conn):
    db = conn["UserManage"]
    collection = db["user"]
    administrator_id = generate_id()
    test_id = generate_id()
    guest_id = generate_id()
    collection.insert_many([
        {
            "username":     "Administrator",
            "password":     cipher_hander.encrypt("Administrator-Test-20161001"),
            "email":        "wfj_sc@163.com",
            "_id":          administrator_id,
            "create_time":  generate_clock_time(),
            "sex":          "",
            "age":          "",
            "phone_number": "",
            "qq_number":    "",
            "weixin_number":"",
            "modify_time":  None
        },
        {
            "username":     "test",
            "password":     cipher_hander.encrypt("test"),
            "email":        "test@163.com",
            "_id":          test_id,
            "create_time":  generate_clock_time(),
            "sex":          "",
            "age":          "",
            "phone_number": "",
            "qq_number":    "",
            "weixin_number":"",
            "modify_time":  None
        },
        {
            "username":     "guest",
            "password":     cipher_hander.encrypt("guest"),
            "email":        "guest@163.com",
            "_id":          guest_id,
            "create_time":  generate_clock_time(),
            "sex":          "",
            "age":          "",
            "phone_number": "",
            "qq_number":    "",
            "weixin_number":"",
            "modify_time":  None
        },
    ])
    return administrator_id, test_id, guest_id

def __init_right(conn):
    db = conn["UserManage"]
    collection = db["right"]
    r_user_id = generate_id()
    w_user_id = generate_id()
    r_role_id = generate_id()
    w_role_id = generate_id()
    r_right_id = generate_id()
    w_right_id = generate_id()
    collection.insert_many([
        {
            "_id":                  r_user_id,
            "right_code":           "R",
            "right_code_alias":     u"读",
            "module_name":          "user",
            "module_name_alias":    u"用户",
            "create_time":          generate_clock_time(),
            "modify_time":          None
        },
        {
            "_id":                  w_user_id,
            "right_code":           "W",
            "right_code_alias":     u"写",
            "module_name":          "user",
            "module_name_alias":    u"用户",
            "create_time":          generate_clock_time(),
            "modify_time":          None
        },
        {
            "_id":                  r_role_id,
            "right_code":           "R",
            "right_code_alias":     u"读",
            "module_name":          "role",
            "module_name_alias":    u"角色",
            "create_time":          generate_clock_time(),
            "modify_time":          None
        },
        {
            "_id":                  w_role_id,
            "right_code":           "W",
            "right_code_alias":     u"写",
            "module_name":          "role",
            "module_name_alias":    u"角色",
            "create_time":          generate_clock_time(),
            "modify_time":          None
        },
        {
            "_id":                  r_right_id,
            "right_code":           "R",
            "right_code_alias":     u"读",
            "module_name":          "right",
            "module_name_alias":    u"权限",
            "create_time":          generate_clock_time(),
            "modify_time":          None
        },
        {
            "_id":                  w_right_id,
            "right_code":           "W",
            "right_code_alias":     u"写",
            "module_name":          "right",
            "module_name_alias":    u"权限",
            "create_time":          generate_clock_time(),
            "modify_time":          None
        },
    ])
    return r_user_id, w_user_id, r_role_id, w_role_id, r_right_id, w_right_id

def __init_user_role(conn, user_ids, role_ids):
    data = [
        {
            "user_id":      x[0],
            "role_id":      x[1],
            "modify_time":  None,
            "create_time":  generate_clock_time()
        } for x in zip(user_ids, role_ids)
    ]
    db = conn["UserManage"]
    collection = db["user_role_relationship"]
    collection.insert_many(data)


def __init_role_right(conn, role_ids, right_ids):
    data = []
    admin_role_id = role_ids[0]
    data.extend([
        {
            "role_id":      admin_role_id,
            "right_id":     x,
            "modify_time":  None,
            "create_time":  generate_clock_time()
        } for x in right_ids
    ])
    user_role_id = role_ids[1]
    data.extend([
        {
            "role_id":      user_role_id,
            "right_id":     x,
            "modify_time":  None,
            "create_time":  generate_clock_time()
        } for x in right_ids[:2]
    ])

    db = conn["UserManage"]
    collection = db["role_right_relationship"]
    collection.insert_many(data)


if __name__ == '__main__':
    conn = pymongo.MongoClient('localhost', 27017)
    __clear_collection(conn)
    role_ids  = __init_role(conn)
    user_ids  = __init_user(conn)
    right_ids = __init_right(conn)
    __init_user_role(conn, user_ids, role_ids)
    __init_role_right(conn, role_ids, right_ids)
    conn.close()
    