# -*- coding: utf-8 -*-
# ===================================
# ScriptName : main.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-09-28 10:35
# ===================================
import os.path
import random
import pymongo
import tornado.httpserver
import tornado.web
import tornado.options
import tornado.ioloop
from tornado.web import url
from userModule.user import LoginHandler, LogoutHandler, IndexHandler, \
    NewUserHandler, UserHandler, ForgetPasswordHandler, EditUserHandler
from userModule.role import RoleHandler, NewRoleHandler, EditRoleHandler
from userModule.right import RightHandler, NewRightHandler, EditRightHandler
from tornado.options import define, options

define('port', default=8080, help='run on the given port', type=int)
define('debug', default=True, help='run on the given debug', type=bool)

UUID_REGEX = '[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}'

class Application(tornado.web.Application):
    def __init__(self):
        self.conn = pymongo.MongoClient('localhost', 27017)
        handlers = [
            url(r'/(?:index)?', IndexHandler),
            url(r'/login', LoginHandler, dict(db=self.conn["UserManage"]), name='login'),
            url(r'/logout', LogoutHandler, dict(db=self.conn["UserManage"]), name='logout'),
            url(r'/user/new', NewUserHandler, dict(db=self.conn["UserManage"])),
            url(r'/user/edit/(?P<user_id>%s)?'%UUID_REGEX, EditUserHandler, dict(db=self.conn["UserManage"])),
            url(r'/user/forget', ForgetPasswordHandler, dict(db=self.conn["UserManage"])),
            url(r'/user(?:/)?(?P<user_id>%s)?'%UUID_REGEX, UserHandler, dict(db=self.conn["UserManage"]), name='user'),
            url(r'/role/new', NewRoleHandler, dict(db=self.conn["UserManage"])),
            url(r'/role/edit/(?P<role_id>%s)?'%UUID_REGEX, EditRoleHandler, dict(db=self.conn["UserManage"])),
            url(r'/role(?:/)?(?P<role_id>%s)?'%UUID_REGEX, RoleHandler, dict(db=self.conn["UserManage"]), name='role'),
            url(r'/right/new', NewRightHandler, dict(db=self.conn["UserManage"])),
            url(r'/right/edit/(?P<right_id>%s)?'%UUID_REGEX, EditRightHandler, dict(db=self.conn["UserManage"])),
            url(r'/right(?:/)?(?P<right_id>%s)?'%UUID_REGEX, RightHandler, dict(db=self.conn["UserManage"]), name='right')
        ]

        settings = {
            'template_path': os.path.join(os.path.dirname(__file__), "templates"),
            # 这2行分别说明了模板路径和静态文件路径，在引用静态文件时，需要使用函数static_url()
            'static_path': os.path.join(os.path.dirname(__file__), "static"),
            'cookie_secret': "__TODO:_GENERATE_YOUR_OWN_RANDOM_VALUE_HERE__",
            # 开启调试模式
            'debug': options.debug,
            "xsrf_cookies": True,
            "login_url": "/login"
        }

        tornado.web.Application.__init__(self, handlers, **settings)

if __name__ == '__main__':
    tornado.options.parse_command_line()
    server = tornado.httpserver.HTTPServer(Application())
    server.listen(options.port)
    tornado.ioloop.IOLoop.current().start()

