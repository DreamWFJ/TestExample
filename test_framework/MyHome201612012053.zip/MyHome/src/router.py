#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Author:         WFJ
Version:        0.1.0
FileName:       router.py
CreateTime:     2016-11-26 15:38
"""
from tornado.web import url
from src.node.views import ManageNodeHandler, ToManageNodeHTML, ManageNodeTimeTaskHandler
from src.blog.article import ManageArticleHandler
from src.node.task import ToNodeTaskHTML, NodeBingTaskHandler, ToManageTaskHTML, ManageTaskHandler

route_urls = [
    url(r'/manage/node', ToManageNodeHTML),
    url(r'/manage/node/data', ManageNodeHandler),
    url(r'/manage/timetask', ToManageTaskHTML),
    url(r'/manage/timetask/data', ManageTaskHandler),
    url(r'/node/timetask', ToNodeTaskHTML),
    url(r'/node/timetask/data', NodeBingTaskHandler),
    url(r'/manage/node/timetask', ManageNodeTimeTaskHandler),
    url(r'/manage/article', ManageArticleHandler)
]

if __name__ == '__main__':
    pass