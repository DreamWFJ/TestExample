# -*- coding: utf-8 -*-
# ===================================
# ScriptName : base.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-12-01 14:54
# ===================================

import tornado.web

class BaseHandler(tornado.web.RequestHandler):
    def prepare(self):
        self.db = self.application.db


    