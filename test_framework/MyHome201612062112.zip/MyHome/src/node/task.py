# -*- coding: utf-8 -*-
# ===================================
# ScriptName : task.py
# Author     : WFJ
# Email      : wfj_sc@163.com
# CreateTime : 2016-12-01 14:51
# ===================================
import json
import time
import uuid
from .base import BaseHandler, time2float

class ToNodeTaskHTML(BaseHandler):
    def get(self, *args, **kwargs):
        task_sql = "select _id, task_name from time_task "
        task_data_field = ['_id', 'task_name']
        task_list = [dict(zip(task_data_field, one)) for one in self.db.find(task_sql)]

        node_sql = "select _id, node_name from node_manage "
        node_data_field = ['_id', 'node_name']
        node_list = [dict(zip(node_data_field, one)) for one in self.db.find(node_sql)]
        self.render("node/node_task.html", task_list=task_list, node_list=node_list)

class NodeBingTaskHandler(BaseHandler):
    def get(self, *args, **kwargs):
        total_sql = """SELECT COUNT(*) FROM node_time_task WHERE 1=1 """
        query_sql = "select _id, node_id, task_id, is_period_execute, first_execute_time, time_task_period_num, " \
                   "time_task_period_unit from node_time_task WHERE 1=1 "
        # 查询域
        start_time = self.get_argument('start_time', None)
        sql = " and first_execute_time >={0} ".format(time2float(start_time)) if start_time else ""
        query_sql += sql
        total_sql += sql
        end_time = self.get_argument('end_time', None)
        sql = " and first_execute_time <={0} ".format(time2float(end_time)) if end_time else ""
        query_sql += sql
        total_sql += sql
        # id是模糊查询
        search_id = self.get_argument('search_id', None)
        sql = " and (_id like '%{0}%' or task_id like '%{0}%' or node_id like '%{0}%') ".format(search_id) if search_id else ""
        query_sql += sql
        total_sql += sql

        is_period_execute = self.get_argument('is_period_execute', None)
        sql = " and is_period_execute={0}".format(int(is_period_execute)) if is_period_execute and is_period_execute != '2' else ""
        query_sql += sql
        total_sql += sql

        order_type = self.get_argument("order", "asc")
        sort_name = self.get_argument('sort', "_id")
        query_sql += " ORDER BY %s %s "%(sort_name, order_type)

        offset = self.get_argument('offset', None)
        limit = self.get_argument('limit', None)
        query_sql += " LIMIT {limit} OFFSET {offset}".format(limit=limit, offset=offset) if offset is not None and limit is not None else ""


        last_data = []
        data_field = ['_id', 'node_id', 'task_id', 'is_period_execute','first_execute_time', 'time_task_period_num', 'time_task_period_unit']

        print query_sql
        for one in self.db.find(query_sql):
            last_data.append(dict(zip(data_field, one)))
        total = self.db.find(total_sql)
        return_data = {
            "rows": last_data,
            "total": total[0][0] if total and len(total) else 0
        }

        self.write(json.dumps(return_data))


    def post(self, *args, **kwargs):
        print self.request.uri
        print self.request.body
        node_ids = self.get_body_arguments("node_ids", None)
        time_task_ids = self.get_body_arguments("time_task_ids", None)
        first_execute_time = self.get_argument('first_execute_time', None)
        is_period_execute = self.get_argument('is_period_execute', None)
        is_period_execute = 1 if is_period_execute=='on' else 0
        time_task_period_num = self.get_argument('time_task_period_num', None) if is_period_execute else None
        time_task_period_unit = self.get_argument('time_task_period_unit', None) if is_period_execute else None


        data = []
        # '_id', 'node_id', 'task_id', 'is_period_execute', 'first_execute_time', 'time_task_period_num', 'time_task_period_unit', 'create_time'
        for node_id in node_ids:
            for task_id in time_task_ids:
                data.append((str(uuid.uuid4()), node_id, task_id, int(is_period_execute), first_execute_time, time_task_period_num, time_task_period_unit, time.time()))

        save_sql = '''insert into node_time_task values (?, ?, ?, ?, ?, ?, ?, ?)'''
        print save_sql
        print data
        print node_ids
        print time_task_ids
        self.db.save(save_sql, data)
        self.redirect("/node/timetask")

    def delete(self, *args, **kwargs):
        print self.request.uri
        print self.request.body

class ToManageTaskHTML(BaseHandler):
    def get(self, *args, **kwargs):
        self.render("node/task_manage.html")

class ManageTaskHandler(BaseHandler):
    def get(self, *args, **kwargs):
        total_sql = "SELECT COUNT(*) FROM time_task "
        task_sql = "select _id, task_name, task_function_description, interpreter, download_script_file, has_binding_node, create_time from time_task "
        # 查询域
        search_departmentname = self.get_argument('departmentname', None)
        search_statu = self.get_argument('statu', None)
        print search_departmentname, search_statu, type(search_statu)

        order_type = self.get_argument("order", "asc")
        sort_name = self.get_argument('sort', "_id")
        task_sql += " ORDER BY %s %s "%(sort_name, order_type)

        offset = self.get_argument('offset', None)
        limit = self.get_argument('limit', None)
        task_sql += " LIMIT {limit} OFFSET {offset}".format(limit=limit, offset=offset) if offset is not None and limit is not None else ""


        last_data = []
        data_field = ['_id', 'task_name', 'task_function_description', 'interpreter', 'download_script_file', 'has_binding_node', 'create_time']

        print "task_sql : ", task_sql

        for one in self.db.find(task_sql):
            last_data.append(dict(zip(data_field, one)))
        total = self.db.find(total_sql)

        # pprint.pprint(last_data)
        return_data = {
            "rows": last_data,
            "total": total[0][0] if total and len(total) else 0
        }

        self.write(json.dumps(return_data))


    def post(self, *args, **kwargs):
        print self.request.uri
        print self.request.body

    def delete(self, *args, **kwargs):
        print self.request.uri
        print self.request.body

    