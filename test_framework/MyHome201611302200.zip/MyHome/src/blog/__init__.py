#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Author:         WFJ
Version:        0.1.0
FileName:       __init__.py.py
CreateTime:     2016-11-26 15:37
"""

if __name__ == '__main__':
    pass