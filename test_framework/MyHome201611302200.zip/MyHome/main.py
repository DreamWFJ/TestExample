#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Author:         WFJ
Version:        0.1.0
FileName:       main.py
CreateTime:     2016-11-26 15:27
"""
import uuid
import time
import tornado.web
import tornado.ioloop
import tornado.options
import tornado.httpserver
from tornado.options import options
from src.router import route_urls
from settings import global_settings
from src.db_sqlite3 import Sqlite3DB

app = tornado.web.Application(route_urls)
class MyHomeApp(tornado.web.Application):
    def __init__(self):
        self.db = Sqlite3DB('test.sqlite')
        self._init_db()
        self._init_insert_data()
        tornado.web.Application.__init__(self, route_urls, **global_settings)

    def _init_db(self):
        handler = self.db
        handler.drop_table('node_manage')
        sql = '''create table `node_manage` (
            `_id` varchar(36) not null,
            `node_name` varchar(128) default null,
            `node_ip` varchar(36) default null,
            `auth_user` varchar(32) default null,
            `auth_passwd` varchar(64) default null,
            `node_status` int(1) default null,
            `last_detect_time` float(24) default null,
            `node_description` varchar(128) default null,
            `last_detect_log` varchar(32) default null,
            `create_time` float(24) default null,
            primary key (`_id`)
        )'''
        handler.create_table(sql)

    def _init_insert_data(self):
        handler = self.db
        save_sql = '''insert into 'node_manage' values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'''
        data = [
            (str(uuid.uuid4()), 'test node 1', '10.100.13.164', 'root', 'root', 1, time.time(), 'this the description: test node 1', 'test.log', time.time()),
            (str(uuid.uuid4()), 'test node 2', '20.100.13.161', 'root', 'root', 1, time.time(), 'this the description: test node 2', 'test.log', time.time()),
            (str(uuid.uuid4()), 'test node 3', '30.100.13.162', 'root', 'root', 0, None, 'this the description: test node 3', 'test.log', time.time()),
        ]
        handler.save(save_sql, data)

if __name__ == '__main__':
    tornado.options.parse_command_line()
    server = tornado.httpserver.HTTPServer(MyHomeApp())
    server.listen(options.port)
    tornado.ioloop.IOLoop.current().start()

